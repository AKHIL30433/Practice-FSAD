package com.klu.service;

import org.springframework.stereotype.Service;

@Service
public class MessageService {
 
    public String getMessage() {
      return "Welcome to Spring Boot MVC Application!";
    }
}